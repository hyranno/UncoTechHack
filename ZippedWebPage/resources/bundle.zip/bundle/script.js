console.log("script in zip worked");
